

<?php $__env->startSection('content'); ?>
<article class="mb-5 mt-4 ml-10">
    
    <h2> <?php echo e($menu['jenisPaket']); ?> </h2>
    <p>  <?php echo e($menu['harga']); ?> </p>
    <p ><a href="/pembayaran/">Bayar</a>  </p>
</article>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/menu.blade.php ENDPATH**/ ?>