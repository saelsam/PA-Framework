
 
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2>Sewa Warnet</h2>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Jenis Paket</th>
            <th>Harga</th>
            <th>Waktu</th>
            <th>Metode Bayar</th>
        </tr>
        <?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pembayaran->menus["id"]); ?></td>
            <td><?php echo e($pembayaran->menus["jenisPaket"]); ?></td>
            <td><?php echo e($pembayaran->menus["harga"]); ?></td>
            <td><?php echo e($pembayaran->menus["waktu"]); ?></td>
            <td><?php echo e($pembayaran["jenis"]); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="row text-center">
        <?php echo $pembayarans->links(); ?>

    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/pembayarans/index.blade.php ENDPATH**/ ?>