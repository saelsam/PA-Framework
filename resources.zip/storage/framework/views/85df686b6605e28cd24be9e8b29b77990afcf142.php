
<?php $__env->startSection('content'); ?>

<div class="container px-4 py-5">
<h2 class="pb-2">List 

</h2>
<a href="" class=""><Button class="btn btn-primary mb-3">Tambah</Button></a>
<table class="table border">
    <thead>
        <tr>
            <th scope="col">#hehee</th>
            <th scope="col">Jenis Paket</th>
            <th scope="col">Harga</th>
            <th scope="col">Waktu</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
<tbody>
<?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <th scope="row"><?php echo e($pembayaran->id); ?></th>
    <td><?php echo e($pembayaran->jenis); ?></td>
    <td><?php echo e($pembayaran->nominal); ?></td>
    <td><?php echo e($pembayaran->menu->waktu); ?></td>
    <td><a href="#" class=""><Button class="btn btn-success mb-3">Lihat</Button></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/bayar.blade.php ENDPATH**/ ?>