

<?php $__env->startSection('content'); ?>
<div class="container px-4 py-5">
<h2 class="pb-2 border-bottom">Good Bye Worlds!</h2>
<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">NIM</th>
            <th scope="col">Prodi</th>
        </tr>
    </thead>
<tbody>
<?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <th scope="row"><?php echo e($mahasiswa->id); ?></th>
    <td><?php echo e($mahasiswa->nama); ?></td>
    <td><?php echo e($mahasiswa->nim); ?></td>
    <td><?php echo e($mahasiswa->prodi->nama); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/about.blade.php ENDPATH**/ ?>