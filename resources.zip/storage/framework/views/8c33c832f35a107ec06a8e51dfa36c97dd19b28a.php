
 
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2>Sewa Warnet</h2>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>Jenis Paket</th>
            <th>Harga</th>
            <th>Waktu</th>
        </tr>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td scope="row"><a href="/menus/<?php echo e($menu["id"]); ?>"><?php echo e($menu['jenisPaket']); ?></a></td>
            <td><?php echo e($menu["harga"]); ?></td>
            <td><?php echo e($menu["waktu"]); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="row text-center">
        <?php echo $menus->links(); ?>

    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/menus/index.blade.php ENDPATH**/ ?>