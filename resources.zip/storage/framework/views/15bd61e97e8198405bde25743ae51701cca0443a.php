
<?php $__env->startSection('content'); ?>
<article class="mb-5">
    <table>
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><a href="/menus/<?php echo e($menu["id"]); ?>">Jenis Paket : <?php echo e($menu['jenisPaket']); ?></a></td>
            </tr>
            <tr>
              <td scope="row">Harga :  <?php echo e($menu['harga']); ?> </td>
            </tr>
            <tr>
              <td scope="row">Waktu :  <?php echo e($menu['waktu']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    
    
</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/menus.blade.php ENDPATH**/ ?>