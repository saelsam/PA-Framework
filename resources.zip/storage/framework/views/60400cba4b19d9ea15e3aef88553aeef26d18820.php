
 
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2>CRUD Sewa Warnet</h2>
            </div>
            <div class="float-end">
                <a class="btn btn-success" href="<?php echo e(route('create')); ?>"> Create New menu</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Jenis Paket</th>
            <th>Harga</th>
            <th>Waktu</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($menu->jenisPaket); ?></td>
            <td><?php echo e($menu->harga); ?></td>
            <td><?php echo e($menu->waktu); ?></td>
            <td>
                <form action="<?php echo e(route('destroy',$menu->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('menus.show',$menu->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('menus.edit',$menu->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="row text-center">
        <?php echo $menus->links(); ?>

    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/index.blade.php ENDPATH**/ ?>