<!DOCTYPE html>
<html>
<head>
    <title>Admin Auth Laravel 8 </title>
</head>
<body>
  
<div class="container">
    Welcome, Admin
</div>
   
</body>
</html><?php /**PATH C:\myFile\Semester 5\Praktek\Framework\tokobuku\resources\views/welcome.blade.php ENDPATH**/ ?>